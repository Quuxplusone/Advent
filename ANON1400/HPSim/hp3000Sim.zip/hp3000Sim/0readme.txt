Release 3.1		Apr 10, 2020

. Update SL to include COBOLII libraries.

Release 3.0		Apr  8, 2020

. Now uses release 8 of the HP3000 emulator.
. Reconfigure terminal buffers from 3 to 5 to eliminate terminal buffer overflow.

Release 2.2		Oct 25, 2019

. When using telnet, MPE is configured such that all telnet-based terminals' type defaults
  to 10 which is an hp terminal. The menu used by mgr.games will see user is
  using term type 10 and go into block mode. It is highly unlikely the user has
  an HP terminal emulator and the terminal status request fails resulting in an abort.

  This has been corrected by reconfiguring all terminal devices to default to 
  terminal type 18, which is the non-HP terminal type and will force the menu
  system to use character mode.

Release 2.1		Oct 15, 2019

. To make it slightly easier for linux users, tricore's xeq group now contains
. the scripts:
	cat
	cp
	less
	ll
	ls
	mv
	rm
. the less script runs a newly added program, more. It probably only runs on 
  hp terminal emulators. The more program, in turn, required creating a version
  of the getinfo intrinsic (supplied by Keven Miller).
	
Release 2               Aug 25, 2019

. Increased amount of available disc space.
. Installed MPEZ which, among other things, provides a menuing system.
. Put Kermit, dirk, and soomz into tools.tricore.
. Added Adventure to the Games account.
. Logging in as mgr.games will automatically start the menuing system.
  . To disable menuing, exit the menu (use option X)
  . at : prompt, type SETCATALOG
. Note to self: I have found that using PAGE mode in QUAD on the file UDC.PUB.GAMES 
  will crash the system.
  
Release 1		May 21, 2018

. Packaged together everything necessary to run the HP3000 SIMH. 
. Uploaded PCLINK2 to PUB.SYS so Reflections could be used to transfer files
  to the HP3000 SIMH. 
. Uploaded QUAD to allow easier editing of ASCII files.
. Wrote the document 'HP3000 SIMH setup notes.pdf' which covers some operational
  aspects and how to get files onto the HP3000 via a SIMH tape.
. Located copies of some of the games we used to play and put them
  into the GAMES account. Login as mgr.games.
. Zipped the entire c:\hp3000Simh directory and distributed it from my website.
. Posted on my blog: https://bigdanzblog.wordpress.com/2018/05/21/instructions-for-emulating-an-hp3000-with-simh/



